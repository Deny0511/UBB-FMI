class UI:
    def __init__(self,service):
        self.__service = service

    def afiseaza(self):
        print("""
                 1.Afiseaza numele si tipul de disk pentru toate tipurile de masini virtuale
                 2.Afiseaza pentru fiecare tip existent de diskuri pretul mediu
                 3.Exit
             """)


    def run(self):
        while True:
            try:
                self.afiseaza()
                comand = input("Introduceti o comanda:")
                if comand == "1":
                    prima = float(input("Introduceti prima capacitate de cpu:"))
                    ultima = float(input("Introduceti ultima capacitate de cpu:"))
                    self.__service.get_numele_si_tip_disk(prima,ultima)

                if comand == "2":
                    interval = input("Introduceti un interval orar:")
                    self.__service.media_arit_pe_int(interval)

                if comand == "3":
                    break


            except ValueError as e:
                print(f"Eroare:{e}")