from domeniu.masini_virtuale import MasiniVirtuale

class Repository:
    def __init__(self,cale_catre_fisier):
        self.__objects = {}
        self.__cale_catre_fisier = cale_catre_fisier

    def __citeste_masini_din_fisier(self):
        """
        Functie care citeste din fisier
        :return:
        """
        with open(self.__cale_catre_fisier, 'r') as f:
            lines = f.readlines()
            for line in lines:
                line = line.strip()
                if line != "":
                    parti = line.split(',')
                    id_masina = int(parti[0])
                    nume = parti[1]
                    cpu = parti[2]
                    disk = parti[3]
                    price = parti[4]
                    masina = MasiniVirtuale(id_masina, nume, cpu, disk, price)
                    self.__objects[id_masina] = masina

    def get_all(self):
        return self.__objects



