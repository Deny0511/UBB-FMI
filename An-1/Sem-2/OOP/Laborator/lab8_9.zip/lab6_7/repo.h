
#ifndef REPO_H
#define REPO_H

#include "domain.h"
#include "MyList.h"
#include <vector>
#include <algorithm>
#include <stdexcept>
#include <map>
#include <string>
#include <ostream>
#include <functional>
#include <fstream>
#include <iostream>



class AbsRepo{
public:
    virtual void adauga(const Film& a)=0;

    virtual void modifica(const std::string& titlu, int an, const std::string& nouGen, int nouAn, const std::string& nouActor)=0;

    virtual void sterge(const std::string& titlu, int an)=0;

    virtual const std::vector<Film>& getAll() const noexcept = 0;
    virtual void setAll(const std::vector<Film>& filmeNoi) noexcept=0;
    virtual const Film& cauta(const std::string& titlu, int an) const =0;

    virtual ~AbsRepo()=default;
};



class Repo : public AbsRepo{
private:
    std::vector<Film> filme;

public:
    Repo() = default;
    virtual void adauga(const Film& film);
    virtual void sterge(const std::string& titlu, int an);
    virtual void modifica(const std::string& titlu, int an, const std::string& nouGen, int nouAn, const std::string& nouActor);
    virtual const Film& cauta(const std::string& titlu, int an) const;
    virtual const std::vector<Film>& getAll() const noexcept {return filme;}
    virtual void setAll(const std::vector<Film>& filmeNoi) noexcept{
        filme = std::move(filmeNoi);
    }
    virtual ~Repo();
};

class RepoFile :public Repo {
private:

    std::string numeFisier;


public:
    void writeAllToFile();

    void readAllFromFile();
    RepoFile(std::string numeFisier) :Repo(), numeFisier{ numeFisier } {
        readAllFromFile();
    }

    void adauga(const Film& film) override {
        Repo::adauga(film);
        writeAllToFile();
    }

    void modifica(const std::string& titlu, int an, const std::string& nouGen, int nouAn, const std::string& nouActor) override {
        Repo::modifica(titlu,an,nouGen,nouAn,nouActor);
        writeAllToFile();
    }

    void sterge(const std::string& titlu, int an) override {
        Repo::sterge(titlu,an);
        writeAllToFile();
    }


    ~RepoFile() override {
    }
};

class RepoNou : public AbsRepo {
private:

	std::map<std::string, Film> filme;
	float probabilitate;


public:

	RepoNou() = default;
	explicit RepoNou(float chance);
	void adauga(const Film& film) override {
	}

	void sterge(const std::string& titlu, int an) override {
	}

	void modifica(const std::string& titlu, int an, const std::string& nouGen, int nouAn, const std::string& nouActor) override {
	}


	~RepoNou() override {}
};



class RepositoryException : public std::runtime_error {
public:
    explicit RepositoryException(const std::string& msg) : std::runtime_error(msg) {}
};




#endif //REPO_H
