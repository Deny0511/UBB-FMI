import unittest
from operator import truediv

from bussines.service import Service
from domeniu.sedinte import Sedinte
from repository.repo import Repository
from valid.validator import Validat


class Teste(unittest.TestCase):
    def setUp(self):
        fisier = "fisier2.txt"
        self.repo = Repository(fisier)
        self.valid = Validat()
        self.service = Service(self.repo,self.valid)
        with open("fisier2.txt",'w') as f:
            f.write(f"01.02,17:00,alta,Extraordinara\n")

    def tearDown(self):
        pass

    def test(self):

        self.repo.adauga(Sedinte("30.01","10:00","FP","Normala"))
        self.repo.citeste_din_fisier()
        self.assertEqual(len(self.repo),2)

        try:
            self.service.adauga("30.01","10:00","FP","FP")
            assert False
        except:
            assert True

        try:
            self.service.adauga("30.01","10:00","FP","")
            assert False
        except:
            assert True




