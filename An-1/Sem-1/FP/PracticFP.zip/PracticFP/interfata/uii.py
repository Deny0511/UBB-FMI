class UI:
    def __init__(self,service):
        self.__service = service


    def afiseaza(self):
        print(
            """
            1.Adauga sedinta.
            2.Seteaza o data.
            3.Exporta in fisier.
            4.Exit.
            
            """
        )

    def sedinte_azi(self):
        try:
            sedinte = self.__service.sedinte_azi()
            if sedinte:
                print("Sedintele de azi sunt:")
                for i in sedinte:
                 print(i)
            else:
                print("Nu sunt sedinte azi!")
        except ValueError as e:
            print(e)

    def run(self):
        while True:
            try:
                self.afiseaza()
                comanda = input("Introduceti o comanda:")
                if comanda == "1":
                    data = input("Introduceti data(dd.MM):")
                    ora = input("Introduceti ora(hh:mm):")
                    subiectul = input("Introduceti subiectul:")
                    tipul = input("Introduceti tipul(Normala sau Extraordinara):")
                    self.__service.adauga(data,ora,subiectul,tipul)
                elif comanda == "2":
                    try:
                        data = input("Introduceti data(dd.MM):")
                        sedinte = self.__service.set_data(data)
                        for i in sedinte:
                            print(i)
                    except ValueError as e:
                        print(e)
                elif comanda == "3":
                    try:
                         nume_fisier = input("Introduceti numele fisierului:")
                         caractere = input("Introduceti caractere:")
                         self.__service.export(nume_fisier,caractere)
                    except ValueError as e:
                        print(e)
                elif comanda == "4":
                    break
                else:
                    print("Comanda invalida")

            except ValueError as e:
                print(f"Eroare: {e}")