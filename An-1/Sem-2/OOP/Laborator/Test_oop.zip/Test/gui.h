
#pragma once
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QTableWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>

#include "service.h"

class Gui : public QWidget {
    Q_OBJECT

private:
    Service& service;

    QLineEdit* editNume = new QLineEdit;
    QLineEdit* editTara = new QLineEdit;
    QLineEdit* exportCsv = new QLineEdit;

    QPushButton* btnAdauga = new QPushButton{ "Adauga" };
    QPushButton* btnExport = new QPushButton{ "Export sortat" };

    QSlider* slider = new QSlider(Qt::Horizontal);
    QComboBox comboBox ;
    QTableWidget* tabel = new QTableWidget;

    void initGUI();
    void conect();
    void loadData();
    void exportFisier();

public:
    Gui(Service& srv) : service{ srv } {
        initGUI();
        conect();
        loadData();
        exportFisier();
    }
};
