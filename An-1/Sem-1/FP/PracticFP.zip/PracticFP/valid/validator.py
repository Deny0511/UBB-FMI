from datetime import datetime

class Validat:
    def __init__(self):
        pass

    def valideaza_sedinta(self,sedinta):
        """
        functie care valideaza
        :param sedinta: sedinta care trebuie validata
        :return: -,daca sedinta e valida
                ValueError daca nu e valida
        """
        if sedinta.get_subiectul()=="":
            raise ValueError("Numele nu poate fi gol")
        if sedinta.get_tipul()!="Normala" and sedinta.get_tipul()!="Extraordinara":
            raise ValueError("Tipul trebuie sa fie :Normala sau Extraordinara")

        format_data = "%d.%m"
        format_ora = "%H:%M"
        try:
            datetime.strptime(sedinta.get_data(), format_data)
        except ValueError:
            raise ValueError("Data trebuie sa fie de forma:d.m si sa fie valida.")

        try:
            datetime.strptime(sedinta.get_ora(), format_ora)

        except ValueError:
            raise ValueError("Ora trebuie sa fie de forma:H:M si sa fie valida.")
