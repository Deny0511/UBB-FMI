

class UI:
    def __init__(self,service):
        self.__service = service

    def afisare(self):
        print(
               """
               1.adauga examen
               2.setare data
               3.export examene in fisier 
               4.get all
               5.exit
               """
        )
    def afisare2(self):
        examene = self.__service.get_examen()
        print("Examenele de maine sunt:")
        if not examene:
            print("Nu sunt examene maine")
        for id in examene:
            examen = examene[id]
            print(f"Data:{examen.get_data()},Ora:{examen.get_ora()},Materia:{examen.get_materia()},Sesiunea:{examen.get_sesiunea()}\n")


    def run(self):
        k=0
        data_copie = ""
        while True:
            try:
                self.afisare()
                self.afisare2()
                if k==1:
                    examene = self.__service.set_data(data_copie)
                    print("Examenele din urmatoarele 3 zile dupa data data sunt:")
                    for id in examene:
                        examen = examene[id]
                        print(
                            f"Data:{examen.get_data()},Ora:{examen.get_ora()},Materia:{examen.get_materia()},Sesiunea:{examen.get_sesiunea()}\n")
                comand = input("introduceti o comanda:")
                if comand == "1":
                    id = int(input("introduceti id:"))
                    data = input("introduceti data:")
                    ora = input("introduceti ora:")
                    materia = input("introduceti materia:")
                    sesiunea = input("introduceti sesiunea:")
                    self.__service.add(id,data,ora,materia,sesiunea)
                if comand == "2":
                    data_copie = input("introduceti data(dd.mm):")
                    k=1
                    examene = self.__service.set_data(data_copie)
                    print("Examenele din urmatoarele 3 zile dupa data data sunt:")
                    for id in examene:
                        examen = examene[id]
                        print(f"Data:{examen.get_data()},Ora:{examen.get_ora()},Materia:{examen.get_materia()},Sesiunea:{examen.get_sesiunea()}\n")
                if comand == "3":
                    nume_fisier = input("introduceti nume fisier:")
                    materia = input("introduceti materia:")
                    self.__service.export(nume_fisier,materia)

                if comand == "4":
                    examene = self.__service.get_all()
                    for id in examene:
                        examen = examene[id]
                        print(f"Data:{examen.get_data()},Ora:{examen.get_ora()},Materia:{examen.get_materia()},Sesiunea:{examen.get_sesiunea()}\n")
                if comand == "5":
                    break
            except ValueError as e:
                print(f"Eroare:{e}")
