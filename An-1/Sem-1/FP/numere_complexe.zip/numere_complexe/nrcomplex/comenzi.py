from nrcomplex.nr_complex import NrComplex


# ADAUGARE
def adaugare_numar_complex_la_sfarsit(lista, parte_reala, parte_imaginara):
    """Adauga un numar complex in lista, la sfarsitul acesteia
    input:lista -o lista de numere complexe
          parte_reala - partea reala a numarului complex care se doreste sa fie adaugat
          parte_imaginara - partea imaginara a numarului care se doreste sa fie adaugat
    output:lista - o lista de numere complexe care contine si noul numar adaugat
    """
    lista.append(NrComplex(parte_reala, parte_imaginara))


def adaugare_numar_complex_pe_pozitie(lista, parte_reala, parte_imaginara, pozitie):
    """Adauga un numar complex in lista, pe o pozitie specificata
    input:lista - o lista de numere complexe
          parte_reala - partea reala a numarului complex care se doreste sa fie adaugat
          parte_imaginara - partea imaginara a numarului care se doreste sa fie adaugat
          pozitie - pozitia pe care se doreste sa fie adaugat
    output:lista - o lista de numere complexe care contine si noul numar adaugat
    """
    a = NrComplex(parte_reala, parte_imaginara)
    lista.insert(pozitie, a)

#MODIFICARE

def stergere_numar_complex_de_pe_pozitie(lista, pozitie):
    """Sterge un numar complex din lista, de pe o pozitie specificata
    input:lista -o lista de numere complexe
          pozitie - pozitia de pe care se doreste sa fie sters numarul
    output:lista -o lista de numere complexe actualizata
    """
    if 0 <= pozitie < len(lista):
        lista.pop(pozitie)

def stergerea_elementelor_de_pe_un_interval_pozitii(lista, prima, ultima):
    """Șterge elementele din lista de numere complexe pe un interval de poziții.
    input:lista -o lista de numere complexe
          prima - prima pozitie de la se doreste stergerea numerelor complexe
          ultima - ultima pozitie la care se doreste sa se opreasca stergerea numerelor complexe
    output:lista -o lista de numere complexe actualizata
    """
    del lista[prima:ultima + 1]

def inlocuire_numar_complex(lista, vechi_real, vechi_imaginar, nou_real, nou_imaginar):
    """Înlocuiește toate aparițiile unui număr complex cu un alt numar complex.
    input:lista -o lista de numere complexe
          vechi_real - partea reala a numarului care se doreste sa fie inlocuit
          vechi_imaginar - partea imaginara a numarului care se doreste sa fie inlocuit
          nou_real - partea reala a numarului cu care se doreste sa se faca inlocuirea
          nou_imaginar - partea imaginara a numarului cu care se doreste sa se faca inlocuirea
    output:lista -o lista de numere complexe actualizata cu noul numar
    """
    for i in range(len(lista)):
        if (lista[i].real == vechi_real) and (lista[i].imaginar == vechi_imaginar):
            lista[i].real = nou_real
            lista[i].imaginar = nou_imaginar


#CAUTARE NUMERE

def afiseaza_partea_imaginara(lista,prima,ultima):
    """Returneaza o lista cu partile imaginare ale numerelor dintr-un interval.
    input: lista - o lista cu numere complexe
           prima - pozitia de la care se incepe afisarea partilor imaginare ale numerelor
           ultima - pozitia la care se opreste afisarea partilor imaginare ale numerelor
    output: lista cu partile imaginare ale numerelor
    """
    parti_imaginare = []
    for i in lista[prima:ultima+1]:
        parti_imaginare.append(i.imaginar)
    return parti_imaginare

def afisare_nr_modul_maimic10(lista):
    """
    Returneaza o lista cu numerele complexe care au modulul mai mic decat 10.
    :param lista: o lista cu numere complexe
    :return: o lista cu numerele complexe a caror modul este mai mic decat 10.
    """
    lista_modul = []
    for num in lista:
        if num.modul() < 10:
            lista_modul.append(num)
    return lista_modul

def afisare_nr_modul_egal10(lista):
    """
        Returneaza o lista cu numerele complexe care au modulul egal cu 10.
        :param lista: o lista cu numere complexe
        :return: o lista cu numerele complexe a caror modul este egal cu 10.
        """
    lista_modul = []
    for num in lista:
        if num.modul() == 10:
            lista_modul.append(num)
    return lista_modul

#OPERATII CU NUMERE

def suma_subsecventa(lista, prima, ultima):
    """
     Calculează suma numerelor dintr-o subsecvență specificată.
    :param lista:  o lista cu numere complexe
    :param prima: pozitia de la care se incepe sa se calculeze suma numerelor
    :param ultima: pozitia la care se opreste calcularea sumei numerelor
    :return: suma numerelor complexe din subsecventa data
    """

    suma_real = 0
    suma_imaginar = 0
    for nr in lista[prima:ultima + 1]:
        suma_real += nr.real
        suma_imaginar += nr.imaginar
    suma=NrComplex(suma_real, suma_imaginar)
    return suma

def produs_subsecventa(lista, prima, ultima):
    """
    Calculează produsul numerelor dintr-o subsecvență specificată.

    :param lista: o lista cu numere complexe
    :param prima: pozitia de la care se incepe sa se calculeze produsul numerelor
    :param ultima: pozitia la care se opreste calcularea  produsului numerelor
    :return: produsul numerelor complexe din subsecventa data
    """
    produs_real=1
    produs_imaginar = 1
    produs_real1 = lista[prima].real
    produs_real2 = lista[prima].real
    produs_imaginar1 = lista[prima].imaginar
    produs_imaginar2 = lista[prima].imaginar
    for nr in lista[prima+1:ultima + 1]:
        produs_real1 *=nr.real
        produs_real2 *=nr.imaginar
        produs_imaginar1 *= nr.real
        produs_imaginar2 *= nr.imaginar
        produs_real=produs_real1-produs_imaginar2
        produs_imaginar=produs_real2+produs_imaginar1
        produs_real1=produs_real
        produs_real2=produs_real
        produs_imaginar1=produs_imaginar
        produs_imaginar2=produs_imaginar
    produs=NrComplex(produs_real, produs_imaginar)
    return produs
def sortare_descrescator(lista):
     """
     Tipareste lista sortata descrescator dupa partea imaginara
     :param lista: o lista cu numere complexe
     :return: lista sortata descrescator dupa partea imaginara
     """
     #return sorted(lista)
     n=len(lista)
     for i in range(n):
         for j in range(i+1,n):
             if lista[i].imaginar<=lista[j].imaginar:
                 lista[i],lista[j]=lista[j],lista[i]


#FILTRARE

def filtrare_parte_reala_prim(lista):
    """
    Elimină toate numerele din lista la care partea reală este un număr prim.
    :param lista: o lista de numere complexe
    :return: o lista filtrata in care elementele a caror parte reala este numar prim, sunt eliminate
    """

    lista_filtrata = []
    for nr_complex in lista:
        parte_reala = nr_complex.real
        if parte_reala <= 1:
            lista_filtrata.append(nr_complex)
            continue
        prim = True
        for j in range(2, int(parte_reala ** 0.5) + 1):
            if parte_reala % j == 0:
                prim = False
                break
        if not prim:
            lista_filtrata.append(nr_complex)
    return lista_filtrata

def filtrare_modul(lista,optiune,n):
    """
     Elimina din lista numerele complexe la care modulul este <,= sau > decât un număr dat.
    :param lista:o lista de numere complexe
    :param optiune: o optiune numerotata de la 1 la 3, prima fiind <,a doua = si a treia>
    :param n: numarul cu care o sa fie comparat modulul numarului complex
    :return:o lista care are doar elementele a caror modul este <,= sau > decat n;
    """

    lista_filtrata = []
    for nr in lista:
        modul=nr.modul()
        if optiune == 1 and modul >= n:
            lista_filtrata.append(nr)
        elif optiune == 2 and modul != n :
            lista_filtrata.append(nr)
        elif optiune == 3 and modul<= n:
            lista_filtrata.append(nr)
    return lista_filtrata




