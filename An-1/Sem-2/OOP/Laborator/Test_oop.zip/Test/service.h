
#ifndef SERVICE_H
#define SERVICE_H
#include "domeniu.h"
#include "repo.h"
#include "validator.h"

class Service {
private:
    Repo& repo;
    Validator& validator;

public:
    Service(Repo& repo,Validator& validat):repo{repo}, validator{validat} {}
    ~Service()=default;

    void addJucator(const std::string& nume, const std::string& tara);
    /*Functie care adauga un nou jucator
     */
    const std::vector<Jucator>& getAll() const;
    /*Functie care retruneaza un vector cu toti jucatorii
     */

};

#endif //SERVICE_H

