

#include "validator.h"
#include <stdexcept>
#include <sstream>

void Validator::valideaza(const Jucator& juc) {
    std::stringstream erori;
    if (juc.getNume().size() < 3) erori << "Numele este prea scurt!\n";
    if (juc.getTara().size() < 3) erori << "Numele tarii este prea scurta!\n";
    if (!isupper(juc.getTara()[0])) erori << "Numele tarii trebuie sa inceapa cu litera mare!\n";
    if (juc.getNume().find(' ') == std::string::npos) erori << "Numele trebuie sa aiba cel putin doua cuvinte!\n";

    if (!erori.str().empty()) throw std::invalid_argument(erori.str());
}
