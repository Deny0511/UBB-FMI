from datetime import datetime,timedelta

from domeniu import examene
from domeniu.examene import Examene


class Repository:
    def __init__(self,cale_fisier):
        self.__cale_fisier = cale_fisier
        self.__dictionar_examene = {}

    def citeste_din_fisier(self):
        with open(self.__cale_fisier,'r') as f:
            self.__dictionar_examene.clear()
            lines = f.readlines()
            for line in lines:
                line = line.strip()
                if line!="":
                    parti = line.split(",")
                    id = parti[0]
                    data = parti[1]
                    ora = parti[2]
                    materia = parti[3]
                    sesiunea = parti[4]
                    examen = Examene(id,data,ora,materia,sesiunea)
                    self.__dictionar_examene[id] = examen

    def append(self,examen):
        with open(self.__cale_fisier,'a') as f:
            f.write(f"{examen.get_id()},{examen.get_data()},{examen.get_ora()},{examen.get_materia()},{examen.get_sesiunea()}\n")

    def write(self):
        with open(self.__cale_fisier,'w') as f:
            for materie in self.__dictionar_examene:
                examen = self.__dictionar_examene[materie]
                f.write(f"{examen.get_id()},{examen.get_data()},{examen.get_ora()},{examen.get_materia()},{examen.get_sesiunea()}\n")

    def add(self,examen):
        self.citeste_din_fisier()
        id = examen.get_id()
        for id,ex in self.__dictionar_examene.items():
            if ex.get_materia() == examen.get_materia() and ex.get_sesiunea() == examen.get_sesiunea():
                raise ValueError(f"Exista deja un examen la materia {ex.get_materia()} de tip {ex.get_sesiunea()}")

        self.__dictionar_examene[id] = examen
        self.append(examen)

    def get_examen(self):
        self.citeste_din_fisier()
        examene_viitoare = {}
        format_data = "%d.%m"
        format_ora = "%H:%M"
        data_curenta = datetime.today()
        data_curenta_simpla = datetime.strptime(data_curenta.strftime(format_data), format_data)
        data_viitoare = data_curenta_simpla + timedelta(days=1)

        for id,examen in self.__dictionar_examene.items():
            examen = self.__dictionar_examene[id]
            data = datetime.strptime(examen.get_data(),format_data)
            ora = datetime.strptime(examen.get_ora(),format_ora)
            if data_curenta_simpla<data<= data_viitoare:
                examene_viitoare[id] = examen
        examene_ordonate = dict(sorted(examene_viitoare.items(),key=lambda item:datetime.strptime(item[1].get_ora(),format_ora)))
        return examene_ordonate

    def get_all(self):
        self.citeste_din_fisier()
        return self.__dictionar_examene


    def set_data(self,data):
        self.citeste_din_fisier()
        examene_viitoare = {}
        format_data = "%d.%m"
        data = datetime.strptime(data,format_data)
        data_curenta_simpla = datetime.strptime(data.strftime(format_data), format_data)
        data_viitoare = data_curenta_simpla + timedelta(days=3)

        for id, examen in self.__dictionar_examene.items():
            examen = self.__dictionar_examene[id]
            data = datetime.strptime(examen.get_data(), format_data)

            if data_curenta_simpla < data <= data_viitoare:
                examene_viitoare[id] = examen
        return examene_viitoare
    def export(self,nume_fisier,materia):
        examene_filtrate = [examen for examen in self.__dictionar_examene.values() if materia in examen.get_materia()]
        examene_filtrate.sort(key=lambda x: (x.get_data(),x.get_ora()))
        with open(nume_fisier,'w') as f:
            for examen in examene_filtrate:
                f.write(f"{examen.get_id()},{examen.get_data()},{examen.get_ora()},{examen.get_materia()},{examen.get_sesiunea()}\n")

