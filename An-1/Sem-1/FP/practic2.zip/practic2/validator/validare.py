from datetime import datetime

class Validat:
    def __init__(self):
        pass
    def valideaza_examen(self,examen):

        if examen.get_id()<0:
            raise ValueError("id invalid")
        if examen.get_materia()=="":
            raise ValueError("materie invalida")
        if examen.get_sesiunea()!="Normala" and examen.get_sesiunea()!="Restanta":
            raise ValueError("sesiunea invalida")
        try:
            format_data = "%d.%m"
            format_ora = "%H:%M"
            data_obj = datetime.strptime(examen.get_data(),format_data)
            ora_obj = datetime.strptime(examen.get_ora(),format_ora)
            data_curenta = datetime.now()
            data_curenta_simpla = datetime.strptime(data_curenta.strftime(format_data),format_data)
            if data_obj<data_curenta_simpla:
                raise ValueError("data trebuie sa fie in viitor")
            ora_min = datetime.strptime("08:00",format_ora)
            ora_max = datetime.strptime("22:00",format_ora)
            if not (ora_min.time()<=ora_obj.time()<=ora_max.time()):
                raise ValueError("ora trebuie sa fie intre 08:00 si 22:00")
        except ValueError:
            raise ValueError("Asigura-te ca lunile sunt intre 1-12 si zilele corespund si ora corespunde")

