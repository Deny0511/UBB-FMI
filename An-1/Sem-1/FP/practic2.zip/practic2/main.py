from bussines.service import Service
from repository.repo import Repository
from ui.uii import UI
from validator.validare import Validat

cale_fisier = "examene.txt"
repo = Repository(cale_fisier)
valid = Validat()
service = Service(repo, valid)
ui = UI(service)
ui.run()