// #include "gui.h"
// #include <QMessageBox>
// #include <QListView>
// #include <QStringListModel>
//
// GUI::GUI(Service& srv, QWidget* parent)
//     : QWidget(parent), service(srv)
// {
//     // Creare Layout principal
//     mainLayout = new QVBoxLayout{this};
//
//     // Câmpuri de text pentru introducerea datelor
//     titluEdit = new QLineEdit{this};
//     genEdit = new QLineEdit{this};
//     anEdit = new QLineEdit{this};
//     actorEdit = new QLineEdit{this};
//
//     // Setare etichete
//     titluEdit->setPlaceholderText("Titlu");
//     genEdit->setPlaceholderText("Gen");
//     anEdit->setPlaceholderText("An");
//     actorEdit->setPlaceholderText("Actor");
//
//     // Butoane
//     adaugaButton = new QPushButton("Adaugă Film", this);
//     stergeButton = new QPushButton("Șterge Film", this);
//     modificaButton = new QPushButton("Modifică Film", this);
//     undoButton = new QPushButton("Undo", this);
//
//     // ListView pentru filme
//     listView = new QListView{this};
//
//     // Layout pentru câmpuri și butoane
//     QVBoxLayout* inputLayout = new QVBoxLayout;
//     inputLayout->addWidget(titluEdit);
//     inputLayout->addWidget(genEdit);
//     inputLayout->addWidget(anEdit);
//     inputLayout->addWidget(actorEdit);
//
//     QHBoxLayout* buttonLayout = new QHBoxLayout;
//     buttonLayout->addWidget(adaugaButton);
//     buttonLayout->addWidget(stergeButton);
//     buttonLayout->addWidget(modificaButton);
//     buttonLayout->addWidget(undoButton);
//
//     mainLayout->addLayout(inputLayout);
//     mainLayout->addLayout(buttonLayout);
//     mainLayout->addWidget(listView);
//
//     // Conectare semnale
//     connect(adaugaButton, &QPushButton::clicked, this, &GUI::adaugaFilm);
//     connect(stergeButton, &QPushButton::clicked, this, &GUI::stergeFilm);
//     connect(modificaButton, &QPushButton::clicked, this, &GUI::modificaFilm);
//     connect(undoButton, &QPushButton::clicked, this, &GUI::undo);
//
//     // Inițializare listView cu filmele din repo
//     actualizeazaListaFilme();
// }
//
// GUI::~GUI() {
// }
//
//
// // Funcția pentru actualizarea listView
// void GUI::actualizeazaListaFilme() {
//     const auto& filme = service.getFilme(); // presupunând că există un getAllFilme() în Service
//     QStringList filmeList;
//     for (const auto& film : filme) {
//         filmeList.append(QString::fromStdString(film.getTitlu()));
//     }
//
//     QStringListModel* model = new QStringListModel(filmeList, this);
//     listView->setModel(model);
// }
//
// // Funcția de adăugare a unui film
// void GUI::adaugaFilm() {
//     QString titlu = titluEdit->text();
//     QString gen = genEdit->text();
//     int an = anEdit->text().toInt();
//     QString actor = actorEdit->text();
//
//     try {
//         service.adaugaFilm(titlu.toStdString(), gen.toStdString(), an, actor.toStdString());
//         QMessageBox::information(this, "Succes", "Film adăugat!");
//         actualizeazaListaFilme(); // Actualizează lista
//     } catch (const std::exception& e) {
//         QMessageBox::warning(this, "Eroare", e.what());
//     }
// }
//
// // Funcția de ștergere a unui film
// void GUI::stergeFilm() {
//     QString titlu = titluEdit->text();
//     int an = anEdit->text().toInt();
//
//     try {
//         service.stergeFilm(titlu.toStdString(), an);
//         QMessageBox::information(this, "Succes", "Film șters!");
//         actualizeazaListaFilme(); // Actualizează lista
//     } catch (const std::exception& e) {
//         QMessageBox::warning(this, "Eroare", e.what());
//     }
// }
//
// // Funcția de modificare a unui film
// void GUI::modificaFilm() {
//     QString titlu = titluEdit->text();
//     int an = anEdit->text().toInt();
//     QString nouGen = genEdit->text();
//     int nouAn = anEdit->text().toInt();
//     QString nouActor = actorEdit->text();
//
//     try {
//         service.modificaFilm(titlu.toStdString(), an, nouGen.toStdString(), nouAn, nouActor.toStdString());
//         QMessageBox::information(this, "Succes", "Film modificat!");
//         actualizeazaListaFilme(); // Actualizează lista
//     } catch (const std::exception& e) {
//         QMessageBox::warning(this, "Eroare", e.what());
//     }
// }
//
// // Funcția undo
// void GUI::undo() {
//     try {
//         service.undo();
//         QMessageBox::information(this, "Succes", "Undo realizat!");
//         actualizeazaListaFilme(); // Actualizează lista
//     } catch (const std::runtime_error& e) {
//         QMessageBox::warning(this, "Eroare", e.what());
//     }
// }
