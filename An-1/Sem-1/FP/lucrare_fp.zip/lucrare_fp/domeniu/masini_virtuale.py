class MasiniVirtuale:
    def __init__(self,id_masina,nume,cpu_capacity,disk_type,price):
        self.__id_masina=id_masina
        self.__nume=nume
        self.__cpu_capacity=cpu_capacity
        self.__disk_type=disk_type
        self.__price=price

    def get_id_masina(self):
        return self.__id_masina

    def get_nume(self):
        return self.__nume

    def get_cpu_capacity(self):
        return self.__cpu_capacity

    def get_disk_type(self):
        return self.__disk_type

    def get_price(self):
        return self.__price

    def __str__(self):
        return f"ID:{self.get_id_masina()} Nume:{self.get_nume()} CPU:{self.get_cpu_capacity()} Disk Type:{self.get_disk_type()} Pret:{self.get_price()}"
