class Examene:
    def __init__(self,id,data,ora,materia,sesiunea):
        self.__id = id
        self.__data = data
        self.__ora = ora
        self.__materia = materia
        self.__sesiunea = sesiunea

    def get_id(self):
        return self.__id

    def get_data(self):
        return self.__data

    def get_ora(self):
        return self.__ora

    def get_materia(self):
        return self.__materia

    def get_sesiunea(self):
        return self.__sesiunea

