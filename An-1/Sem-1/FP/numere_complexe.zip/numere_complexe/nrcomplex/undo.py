from nrcomplex.nr_complex import NrComplex

def istoric(lista,undo_lista):
    """
    Salvează starea curentă a listei în stiva de undo.

    :param lista: O listă care reprezintă starea curentă.
    :return: None
    """
    lista_istoric = []
    for i in lista:
        lista_istoric.append(NrComplex(i.real, i.imaginar))
    undo_lista.append(lista_istoric)

def undo(lista,undo_lista):
    """
     Revine la ultima stare a listei prin intermediul unui mecanism de undo.

    :param lista: O listă care reprezintă starea curentă.
    :return: O listă care reprezintă starea anterioară sau lista originală dacă nu există stări anterioare.
    """
    if undo_lista:
        return undo_lista.pop()  # Revine la ultima stare
    else:
        print("Nu există stări anterioare pentru a face undo.")
        return lista
