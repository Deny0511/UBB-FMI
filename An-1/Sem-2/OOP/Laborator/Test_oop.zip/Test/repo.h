
#ifndef REPO_H
#define REPO_H
#include <iostream>
#include <string.h>
#include <vector>
#include "domeniu.h"

class Repo{
  private:
    std::vector<Jucator> jucator;

  public:
    Repo()=default;
    void setAll(const std::vector<Jucator>& jucatorNou);
  /*Functie care seteaza toate elementele din Jucator
   */
    const std::vector<Jucator>& getAll()const;
  /*Functie care returneaza un vector cu toti jucatorii
   */
    void adauga(const Jucator& juc);
  /*Functie care adauga un nou jucator
   */


    ~Repo()=default;

};

#endif //REPO_H

