#include "service.h"
#include <random>

void Service::addJucator(const std::string& nume, const std::string& tara) {
    std::mt19937 mt{ std::random_device{}() };
    std::uniform_int_distribution<> distMeciuri(0, 100);
    std::uniform_int_distribution<> distPuncte(10, 1000);
    std::uniform_int_distribution<> distRecuperari(10, 500);
    std::uniform_int_distribution<> distAssist(10, 500);

    Jucator j{ nume, tara, distMeciuri(mt), distPuncte(mt), distRecuperari(mt), distAssist(mt) };
    validator.valideaza(j);
    repo.adauga(j);
}

const std::vector<Jucator>& Service::getAll() const {
    return repo.getAll();
}
