class Sedinte:
    def __init__(self,data,ora,subiectul,tipul):
        self.__data=data
        self.__ora=ora
        self.__subiectul=subiectul
        self.__tipul=tipul


    def get_data(self):
        return self.__data

    def get_ora(self):
        return self.__ora

    def get_subiectul(self):
        return self.__subiectul

    def get_tipul(self):
        return self.__tipul

