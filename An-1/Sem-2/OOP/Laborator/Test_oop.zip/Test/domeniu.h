
#ifndef DOMENIU_H
#define DOMENIU_H
#include <string.h>
#include <iostream>

class Jucator{
  private:
    std::string nume;
    std::string tara;
    int meciuri;
    int puncte;
    int recuperari;
    int assist;
  public:
    Jucator():nume(""),tara(""),meciuri(0),puncte(0),recuperari(0),assist(0){};
    Jucator(const std::string& nume,const std::string& tara,int meciuri,int puncte,int recuperari,int assist)
  : nume(nume), tara(tara), meciuri(meciuri), puncte(puncte), recuperari(recuperari), assist(assist) {}


    const std::string& getNume()const{return nume;};
    const std::string& getTara()const{return tara;};
    int getMeciuri()const{return meciuri;};
    int getPuncte()const{return puncte;};
    int getRecuperari()const{return recuperari;};
    int getAssist()const{return assist;};

    void setNume(std::string& numeNou){ nume = numeNou;};
    void setTara(std::string& taraNou){ tara = taraNou;};
    void setMeciuri(int meciuriNou){ meciuri = meciuriNou;};
    void setPuncte(int puncteNou){ puncte = puncteNou;};
    void setRecuperari(int recuperariNou){recuperari= recuperariNou;};
    void setAssist(int assistNou){assist = assistNou;};


  bool operator==(const Jucator& other) const {
    return nume == other.nume &&
           tara == other.tara &&
           meciuri == other.meciuri &&
           puncte == other.puncte &&
           recuperari == other.recuperari &&
           assist == other.assist;
  }

    ~Jucator(){};

};

#endif //DOMENIU_H





