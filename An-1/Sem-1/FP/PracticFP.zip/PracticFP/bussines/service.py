from domeniu.sedinte import Sedinte


class Service:
    def __init__(self,repo,valid):
        self.__repo = repo
        self.__valid = valid

    def adauga(self,data,ora,subiectul,tipul):
        """
        Functie care adauga o sedinta in fisier
        :param data: data la care are loc sedinta(dd.mm)
        :param ora: ora la care are loc sedinta(H:M)
        :param subiectul: numele subiectului sedinta (tip string)
        :param tipul: tipul sedintei de tip string, acesta poate fi:Normala sau Extraordinara
        :return: -
        """
        sedinta = Sedinte(data,ora,subiectul,tipul)
        self.__valid.valideaza_sedinta(sedinta)
        self.__repo.adauga(sedinta)

    def sedinte_azi(self):#
        """
        Functie care returneaza toate sedintele care au loc azi
        :return: lista de sedinte de azi
        """
        return self.__repo.sedinte_azi()

    def set_data(self,data):
        """
         Functie care primeste o data si returneaza toate sedintele care au lod dupa data data
        :param data: data de forma dd.mm
        :return: sedintele care are loc in urmatoarele 3 zile
        """
        return self.__repo.set_data(data)

    def export(self,nume_fisier,caractere):
        """
        Functie care exporta sedinta in fisierul cu numele dat daca subiectul sedintei contine caracterele date
        :param nume_fisier: numele fisierului unde se exporta
        :param caractere: caractere tip string
        :return: -
        """
        self.__repo.export(nume_fisier,caractere)