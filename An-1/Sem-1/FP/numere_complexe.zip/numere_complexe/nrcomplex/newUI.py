from nrcomplex.UI import afiseaza_lista
from nrcomplex.comenzi import *
from nrcomplex.undo import *

def meniu_new(comanda,lista,undo_lista):
    param=comanda.split(' ')
    op= param[0]
    if op=="adaugare":
        if len(param) == 3:
            parte_reala = int(param[1])
            parte_imaginara = int(param[2])
            adaugare_numar_complex_la_sfarsit(lista, parte_reala, parte_imaginara)
            undo_lista.append(lista[:])
            afiseaza_lista(lista)
        else:
            print("Utilizare incorectă. Forma corectă este: adaugare <parte_reala> <parte_imaginara>")
    elif op=="stergere":
        if len(param) == 2:
            pozitie = int(param[1])
            stergere_numar_complex_de_pe_pozitie(lista, pozitie)
            undo_lista.append(lista[:])
            afiseaza_lista(lista)
        else:
            print("Utilizare incorectă. Forma corectă este: stergere <pozitie>")
    elif op=="cautare":
        if len(param) == 3:
            prima = int(param[1])
            ultima = int(param[2])
            parti_imaginare = afiseaza_partea_imaginara(lista, prima, ultima)
            print(f"Părțile imaginare din intervalul [{prima}, {ultima}]: {parti_imaginare}")
        else:
            print("Utilizare incorectă. Forma corectă este: afiseaza_imaginare <prima> <ultima>")
    elif op=="suma":
        if len(param) == 3:
            prima = int(param[1])
            ultima = int(param[2])
            suma = suma_subsecventa(lista, prima, ultima)
            print(f"Suma numerelor din intervalul [{prima}, {ultima}] este: {suma}")
        else:
            print("Utilizare incorectă. Forma corectă este: suma <prima> <ultima>")
    elif op=="filtrare":
        lista_filtrata = filtrare_parte_reala_prim(lista)
        print(f"Lista filtrată: {lista_filtrata}")
    elif op=="undo":
        undo(lista, undo_lista)
        afiseaza_lista(lista)
    else:
        print("Optiune invalida.Alege o alta optiune.")
def ruleaza():
    lista=[]
    undo_lista=[]
    while True:
        comanda = input("Introduceti comanda: ")
        meniu_new(comanda, lista, undo_lista)
def afiseaza_lista(lista):
    print("Lista actuală:")
    for i in lista:
        print(i)