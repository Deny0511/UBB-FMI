from nrcomplex.UI import *
from nrcomplex.newUI import *
#rulare_teste()
#meniu()

ruleaza()
