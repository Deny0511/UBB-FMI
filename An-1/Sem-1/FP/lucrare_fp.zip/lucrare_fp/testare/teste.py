import unittest



class Test(unittest.TestCase):
    def setUp(self):
        self.id_masina = 1
        self.nume = "Standard A"
        self.cpu_capacity = 2.5
        self.disk_type = "HDD"
        self.price = 0.05

    def tearDown(self):
        pass

    def test_domeniu(self):
        self.assertEqual(self.id_masina, 1)
        self.assertEqual(self.nume, "Standard A")
        self.assertEqual(self.cpu_capacity, 2.5)
        self.assertEqual(self.disk_type, "HDD")
        self.assertEqual(self.price, 0.05)

