#include "gui.h"
#include <QMessageBox>
#include <QHeaderView>
#include <QBrush>

void Gui::initGUI() {
    auto* layoutMain = new QVBoxLayout;
    auto* layoutForm = new QHBoxLayout;

    editNume->setPlaceholderText("Nume");
    editTara->setPlaceholderText("Tara de origine");

    layoutForm->addWidget(editNume);
    layoutForm->addWidget(editTara);
    layoutForm->addWidget(btnAdauga);

    tabel->setColumnCount(6);
    QStringList header{ "Nume", "Tara", "Meciuri", "Puncte", "Recuperari", "Assist-uri" };
    tabel->setHorizontalHeaderLabels(header);
    tabel->horizontalHeader()->setStretchLastSection(true);

    layoutMain->addLayout(layoutForm);
    layoutMain->addWidget(tabel);
    setLayout(layoutMain);
}

void Gui::conect() {
    QObject::connect(btnAdauga, &QPushButton::clicked, this, [&]() {
        QString nume = editNume->text();
        QString tara = editTara->text();
        try {
            service.addJucator(nume.toStdString(), tara.toStdString());
            loadData();
            editNume->clear();
            editTara->clear();
        } catch (const std::exception& ex) {
            QMessageBox::warning(this, "Eroare", ex.what());
        }
    });
}

void Gui::loadData() {
    const auto& jucatori = service.getAll();
    tabel->setRowCount(static_cast<int>(jucatori.size()));

    for (int i = 0; i < jucatori.size(); ++i) {
        const auto& j = jucatori[i];
        double mediePuncte = j.getPuncte() * 1.0 / j.getMeciuri();
        double medieRecuperari = j.getRecuperari() * 1.0 / j.getMeciuri();
        double medieAssist = j.getAssist() * 1.0 / j.getMeciuri();

        bool tripleDouble = mediePuncte >= 10 && medieRecuperari >= 10 && medieAssist >= 10;

        tabel->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(j.getNume())));
        tabel->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(j.getTara())));
        tabel->setItem(i, 2, new QTableWidgetItem(QString::number(j.getMeciuri())));
        tabel->setItem(i, 3, new QTableWidgetItem(QString::number(j.getPuncte())));
        tabel->setItem(i, 4, new QTableWidgetItem(QString::number(j.getRecuperari())));
        tabel->setItem(i, 5, new QTableWidgetItem(QString::number(j.getAssist())));

        if (tripleDouble) {
            for (int col = 0; col < 6; ++col)
                tabel->item(i, col)->setBackground(QBrush(Qt::green));
        }
    }
}


void Gui::exportFisier() {
    slider->setMinimum(1);
    slider->setMaximum(100);


}