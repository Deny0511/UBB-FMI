from domeniu.sedinte import Sedinte
from datetime import datetime


class Repository:
    def __init__(self,cale_fisier):
        self.__cale_fisier = cale_fisier
        self.__dictionar_sedinte = {}

    def citeste_din_fisier(self):
        """
        Functie care citeste din fisier
        :return: -
        """
        with open(self.__cale_fisier,'r') as f:
            self.__dictionar_sedinte.clear()
            lines = f.readlines()
            for line in lines:
                line = line.strip()
                if line !="":
                    parti = line.split(",")
                    data = parti[0]
                    ora = parti[1]
                    subiectul = parti[2]
                    tipul = parti[3]
                    cheia = (data,ora)
                    sedinta = Sedinte(data,ora,subiectul,tipul)
                    self.__dictionar_sedinte[cheia] = sedinta


    def append(self,sedinta):
        """
        Functie care scrie la finalul fisierului
        :param sedinta: sedinta pe care o scrie
        :return: -
        """
        with open(self.__cale_fisier,'a') as f:
            f.write(f"{sedinta.get_data()},{sedinta.get_ora()},{sedinta.get_subiectul()},{sedinta.get_tipul()}\n")


    def write(self):
        """
        Functie care scrie in fisier
        :return: -
        """
        with open(self.__cale_fisier,'w') as f:
            for el in self.__dictionar_sedinte:
                sedinta = self.__dictionar_sedinte[el]
                f.write(f"{sedinta.get_data()},{sedinta.get_ora()},{sedinta.get_subiectul()},{sedinta.get_tipul()}\n")

    def sedinte_azi(self):
        """
         Functie care returneaza toate sedintele care au loc azi
         :return: sedintele de azi
        """
        self.citeste_din_fisier()
        format_data = "%d.%m"
        format_ora = "%H%M"
        data_curenta = datetime.now().strftime(format_data)
        dicti = {}
        for el in self.__dictionar_sedinte:
            sedinta = self.__dictionar_sedinte[el]
            data = datetime.strptime(sedinta.get_data(),format_data)
            ora = datetime.strptime(sedinta.get_ora(),format_ora)
            if data == data_curenta:
                dicti[ora] = str(sedinta)
        dicti = sorted(dicti.items())
        return [x[1] for x in dicti]


    def adauga(self,sedinta):
        """
        Functie care adauga o sedinta in fisier
        :param sedinta:sedinta care se adauga in fisier
        :return: -
        """
        self.citeste_din_fisier()
        for el in self.__dictionar_sedinte:
            sedinta2 = self.__dictionar_sedinte[el]
            if sedinta2.get_subiectul() == sedinta.get_subiectul():
                if sedinta2.get_tipul() == sedinta.get_tipul():
                    raise ValueError("Nu pot exita 2 sedinte pe acelasi subiect")

        self.append(sedinta)

    def set_data(self,data):
        """
        Functie care primeste o data si returneaza toate sedintele care au lod dupa data data
        :param data: data de forma dd.mm
        :return: sedintele care are loc in urmatoarele 3 zile
        """
        self.citeste_din_fisier()
        format_data = "%d.%m"
        format_ora = "%H%M"
        data= datetime.strptime(data,format_data).date()
        dictionar = {}
        for el in self.__dictionar_sedinte:
            sedinta = self.__dictionar_sedinte[el]
            data_ = datetime.strptime(sedinta.get_data(), format_data).date()
            ora = datetime.strptime(sedinta.get_ora(), format_ora)
            if data_ == data or data_ > data :
                dictionar[ora] = str(sedinta)
        return dictionar

    def export(self,nume_fisier,caractere):
        """
        Functie care exporta sedinta in fisierul cu numele dat daca subiectul sedintei contine caracterele date
        :param nume_fisier: numele fisierului unde se exporta
        :param caractere: caractere tip string
        :return: -
        """
        self.citeste_din_fisier()
        for el in self.__dictionar_sedinte:
            sedinta = self.__dictionar_sedinte[el]
            if sedinta.get_subiectul() == caractere:
                  with open(nume_fisier,'a') as f:
                     f.write(f"{sedinta.get_data()},{sedinta.get_ora()},{sedinta.get_subiectul()},{sedinta.get_tipul()}")

    def __len__(self):
        """
        functie care determina lungimea dictionarului
        :return: lungimea dictionarului
        """
        return len(self.__dictionar_sedinte)