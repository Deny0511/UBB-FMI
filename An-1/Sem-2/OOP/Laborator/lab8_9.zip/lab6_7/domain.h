

#ifndef DOMAIN_H
#define DOMAIN_H

#include <string>

class Film {
private:
    std::string titlu, gen, actor_principal;
    int an;
public:
    Film() : titlu(""), gen(""), an(0), actor_principal("") {}
    Film(const std::string& titlu, const std::string& gen, int an, const std::string& actor);
    Film(const Film& other);

    const std::string& getTitlu() const;
    const std::string& getGen() const;
    int getAn() const;
    const std::string& getActor() const;

    bool operator==(const Film& other) const;
    virtual ~Film() = default;
};









#endif //DOMAIN_H
