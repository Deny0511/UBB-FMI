class Validare:
    def __init__(self):
        pass

    def valideaza_interval(self,prima,ultima):
        if prima < 0:
            return ValueError("CPU nu poate fi negativ")
        if ultima < 0:
            return ValueError("CPU nu poate fi negativ")