from repository.repo_masini import Repository
from service.service_masina import ServiceMasina
from validare.validare_masina import Validare
from interfata.ui import UI

cale_fisier = "masina_virtuala.txt"
repo = Repository(cale_fisier)
valid = Validare()
serv = ServiceMasina(repo,valid)
ui = UI(serv)
ui.run()