from nrcomplex.teste import *
from nrcomplex.comenzi import *
from nrcomplex.undo import *


def afiseaza_meniu():
    print("\nMeniu:")
    print("1.Adauga un numar complex la sfarsitul listei.")
    print("2.Adauga numar complex pe o pozitie specificata.")
    print("3.Sterge un numar complex de pe o pozitie.")
    print("4.Sterge elementele de pe pozitiile pe care le doresti.  ")
    print("5.Inlocuieste numarul complex cu un alt numar complex.")
    print("6.Afiseaza partea imaginara incepand de la o pozitie data pana la o alta pozitie data.")
    print("7.Tipărește toate numerele complexe care au modulul mai mic decât 10.")
    print("8. Tipărește toate numerele complexe care au modulul egal 10.")
    print("9.Aduna elementele dintr-o subsecventa.")
    print("10.Inmulteste elementele dintr-o subsecventa. ")
    print("11.Sorteaza lista descrescator dupa partea imaginara.")
    print("12.Elimina numerele din lista la care partea reala este numar prim")
    print("13.Elimina din lista numerele complexe la care modulul este <,= sau > decât un număr dat. ")
    print("14.Reface ultima operație (lista de numere revine la numerele ce existau înainte de ultima operație care a modificat lista).")
    print("15.Iesire din aplicatie.")

def afiseaza_filtrare_modul():
    print("\n1.Elimina numerele a caror modul este mai mic decat numarl dat.")
    print("2.Elimina numerele a caror modul este egal cu numarul dat.")
    print("3.Elimina numerele a caror modul este mai mare decat un numar dat.")

def afiseaza_lista(lista):
    print("Lista actuală:")
    for i in lista:
        print(i)


def rulare_teste():
    test_adaugare_numar_complex_la_sfarsit()
    test_adaugare_numar_complex_pe_pozitie()
    test_stergere_numar_complex_de_pe_pozitie()
    test_stergerea_elementelor_de_pe_un_interval_pozitii()
    test_inlocuire_numar_complex()
    test_afiseaza_partea_imaginara()
    test_afisare_nr_modul_maimic10()
    test_afisare_nr_modul_egal10()
    test_suma_subsecventa()
    test_produs_subsecventa()
    test_sortare_descrescator()
    test_filtrare_parte_reala_prim()
    test_filtrare_modul()
    test_undo()


def meniu():
    lista_numere_complexe = []
    undo_lista = []
    while True:

        afiseaza_meniu()
        optiune = input("Alege o opțiune:")
        if optiune == "1":
            istoric(lista_numere_complexe,undo_lista)
            a = int(input("Introduceți partea reală a numărului pe care doriți să îl adăugați: "))
            b = int(input("Introduceți partea imaginară a numărului pe care doriți să îl adăugați: "))
            adaugare_numar_complex_la_sfarsit(lista_numere_complexe, a, b)
            afiseaza_lista(lista_numere_complexe)

        elif optiune == "2":
            istoric(lista_numere_complexe,undo_lista)
            a = int(input("Introduceți partea reală a numărului pe care doriți să îl adăugați: "))
            b = int(input("Introduceți partea imaginară a numărului pe care doriți să îl adăugați: "))
            c = int(input("Introduceți poziția unde doriți să îl adăugați: "))
            adaugare_numar_complex_pe_pozitie(lista_numere_complexe, a, b, c)
            afiseaza_lista(lista_numere_complexe)

        elif optiune == "3":
            istoric(lista_numere_complexe,undo_lista)
            a = int(input("Introduceți poziția de pe care doriți să ștergeți numărul: "))
            stergere_numar_complex_de_pe_pozitie(lista_numere_complexe, a)
            afiseaza_lista(lista_numere_complexe)

        elif optiune == "4":
            istoric(lista_numere_complexe, undo_lista)
            a = int(input("Introduceți prima poziție de la care doriți să ștergeți numărul: "))
            b = int(input("Introduceți ultima poziție de la care doriți să ștergeți numărul: "))
            stergerea_elementelor_de_pe_un_interval_pozitii(lista_numere_complexe, a, b)
            afiseaza_lista(lista_numere_complexe)

        elif optiune == "5":
            istoric(lista_numere_complexe, undo_lista)
            a = int(input("Introduceți partea reală a numărului pe care doriți să îl înlocuiți: "))
            b = int(input("Introduceți partea imaginară a numărului pe care doriți să îl înlocuiți: "))
            c = int(input("Introduceți partea reală a numărului cu care doriți să îl înlocuiți pe cel vechi: "))
            d = int(input("Introduceți partea imaginară a numărului cu care doriți să îl înlocuiți pe cel vechi: "))
            inlocuire_numar_complex(lista_numere_complexe, a, b, c, d)
            afiseaza_lista(lista_numere_complexe)

        elif optiune == "6":
            istoric(lista_numere_complexe,undo_lista)
            a = int(input("Introduceți prima poziție de la care doriți să se afișeze părțile imaginare: "))
            b = int(input("Introduceți poziția până la care doriți să se afișeze părțile imaginare: "))
            print("Părți imaginare:", afiseaza_partea_imaginara(lista_numere_complexe, a, b))

        elif optiune == "7":
            istoric(lista_numere_complexe, undo_lista)
            print("Numerele sunt:",afisare_nr_modul_maimic10(lista_numere_complexe))
        elif optiune == "8":
            istoric(lista_numere_complexe)
            print("Numerele sunt:", afisare_nr_modul_egal10(lista_numere_complexe))
        elif optiune == "9":
            istoric(lista_numere_complexe, undo_lista)
            a=int(input("Introduceti prima pozitie a subsecventei dorite:"))
            b=int(input("Introduceti ultima pozitie a subsecventei dorite: "))
            print("Suma este:",suma_subsecventa(lista_numere_complexe,a,b))
        elif optiune == "10":
            istoric(lista_numere_complexe,undo_lista)
            a = int(input("Introduceti prima pozitie a subsecventei dorite:"))
            b = int(input("Introduceti ultima pozitie a subsecventei dorite: "))
            print("Produsul este:",produs_subsecventa(lista_numere_complexe,a,b))
        elif optiune == "11":
            istoric(lista_numere_complexe,undo_lista)
            sortare_descrescator(lista_numere_complexe)
            afiseaza_lista(lista_numere_complexe)
        elif optiune == "12":
            istoric(lista_numere_complexe,undo_lista)
            lista_filtrata = filtrare_parte_reala_prim(lista_numere_complexe)
            print("Lista fără numerele complexe a căror parte reală este număr prim este:")
            for nr in lista_filtrata:
                print(nr)
        elif optiune=="13":
            istoric(lista_numere_complexe,undo_lista)
            n = int(input("Introduceti numarul de la care doriti sa eliminati numerele din lista:"))
            afiseaza_filtrare_modul()
            a=input("Alegeti o optiune(1: <, 2: =, 3: >):")
            if a=="1":
                lista_filtrata = filtrare_modul(lista_numere_complexe,1,n)
                print("Lista fara numerele mai mici decat n este:")
                for nr in lista_filtrata:
                    print(nr)
            elif a=="2":
                lista_filtrata=filtrare_modul(lista_numere_complexe,2,n)
                print("Lista fara numerele egale cu n este:")
                for nr in lista_filtrata:
                    print(nr)
            elif a=="3":
                lista_filtrata=filtrare_modul(lista_numere_complexe,3,n)
                print("Lista fara numerele mai mici decat n este:")
                for nr in lista_filtrata:
                    print(nr)
            else:
                print("Optiune invalida.Alege o alta optiune.")
        elif optiune == "14":

            lista_numere_complexe = undo(lista_numere_complexe)
            afiseaza_lista(lista_numere_complexe)
        elif optiune == "15":
            print("Ieșire din aplicație")
            break

        else:
            print("Opțiune invalidă, vă rugăm alegeți una dintre opțiunile date")