#pragma once
#include <string>
#include "domeniu.h"

class Validator {
public:
    void valideaza(const Jucator& juc);
};
