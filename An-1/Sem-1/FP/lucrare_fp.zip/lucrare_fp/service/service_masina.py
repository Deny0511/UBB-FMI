class ServiceMasina:
    def __init__(self,repo,valid):
        self.__repo = repo
        self.__valid = valid

    def get_numele_si_tip_disk(self,prima,ultima):
        """
        Functie care returneaza numele si tipul de disk dintr-un interval dat
        :param prima: prima pozitie de cpu data de la tastatura
        :param ultima: ultima pozitie de cpu data de la tastatura
        :return: numele masinii si tipul daca se afla in intervalul dat
        """
        self.__valid.valideaza_interval(prima, ultima)
        all = self.__repo.get_all()
        obj = []
        for masina in all:
            if masina.get_cpu_capacity >= prima and masina.get_cpu_capacity() <= ultima:
                obj.append(masina)
        if not obj:
            return "Nu exista nicio astfel de masina virtuala "
        for masina in obj:
            return f"Nume: {masina.get_nume()},tip disk: {masina.get_type_disk()}"

    def media_arit_pe_int(self,interval):
        """
        Functie care calculeaza pretul mediu calculat intr-un interval orar dat
        :param interval: intervalul orar dat
        :return:
        """
        all = self.__repo.get_all()
        tip_hdd = []
        tip_ssd = []
        tip_ssd_ultra = []
        i=0
        j=0
        l=0
        for masina in all:
            if masina.get_type_disk == "HDD":
                tip_hdd += masina.get_price
                i += 1
            if masina.get_type_disk == "SSD":
                tip_ssd += masina.get_price
                j += 1
            if masina.get_type_disk == "SSD_ULTRA":
                tip_ssd_ultra += masina.get_price
                l+=1



