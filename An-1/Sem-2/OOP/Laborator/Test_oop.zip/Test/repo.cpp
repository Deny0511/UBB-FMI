#include "repo.h"
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>



void Repo::setAll(const std::vector<Jucator> &jucator_nou) {
    jucator = jucator_nou;
}

void Repo::adauga( const Jucator& juc) {
    auto it = std::find(jucator.begin(),jucator.end(),juc);

    if (it != jucator.end()) {
        throw std::invalid_argument("Trafic already exists");

    }
    jucator.push_back(juc);

}

const std::vector<Jucator>& Repo::getAll() const {
    return jucator;
}



