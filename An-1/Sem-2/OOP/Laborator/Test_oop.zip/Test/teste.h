
#ifndef TESTE_H
#define TESTE_H

class Teste{
public:
    static void ruleazaTeste();
private:
    static void testDomeniu();
    static void testRepo();
    static void testService();
    static void testValidator();

};


#endif //TESTE_H
