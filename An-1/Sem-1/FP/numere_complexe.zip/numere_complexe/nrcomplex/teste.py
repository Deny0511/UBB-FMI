from nrcomplex.comenzi import *
from nrcomplex.nr_complex import NrComplex
from nrcomplex.undo import *

def test_adaugare_numar_complex_la_sfarsit():
    lista = []
    adaugare_numar_complex_la_sfarsit(lista, 3, 4)
    assert len(lista) == 1, f"test esuat: {len(lista)}"
    assert lista[0].real == 3,f"test esuat: {lista[0].real}"
    assert lista[0].imaginar == 4, f"test esuat: {lista[0].imaginar}"

def test_adaugare_numar_complex_pe_pozitie():
    lista = []
    adaugare_numar_complex_la_sfarsit(lista, 4, 7)
    adaugare_numar_complex_la_sfarsit(lista, 3, 9)
    adaugare_numar_complex_pe_pozitie(lista, 2, 5, 1)
    assert len(lista) == 3, f"test esuat: {len(lista)}"
    assert lista[1].real == 2, f"test esuat: {lista[1].real}"
    assert lista[1].imaginar == 5, f"test esuat: {lista[1].imaginar}"

def test_stergere_numar_complex_de_pe_pozitie():
    lista = []
    adaugare_numar_complex_la_sfarsit(lista, 7, 4)
    adaugare_numar_complex_la_sfarsit(lista, 5, 2)
    stergere_numar_complex_de_pe_pozitie(lista, 1)
    assert len(lista) == 1, f"test esuat: {len(lista)}"
    assert lista[0].real == 7,f"test esuat: {lista[0].real}"
    assert lista[0].imaginar == 4,f"test esuat: {lista[0].imaginar}"

def test_stergerea_elementelor_de_pe_un_interval_pozitii():
    lista = []
    adaugare_numar_complex_la_sfarsit(lista, 9, 8)
    adaugare_numar_complex_la_sfarsit(lista, 3, 5)
    adaugare_numar_complex_la_sfarsit(lista, 4, 2)
    stergerea_elementelor_de_pe_un_interval_pozitii(lista, 0, 1)
    assert len(lista) == 1,f"test esuat: {len(lista)}"
    assert lista[0].real == 4,f"test esuat: {lista[0].real}"
    assert lista[0].imaginar == 2,f"test esuat: {lista[0].imaginar}"

def test_inlocuire_numar_complex():
    lista = []
    adaugare_numar_complex_la_sfarsit(lista, 9, 8)
    adaugare_numar_complex_la_sfarsit(lista, 4, 5)
    adaugare_numar_complex_la_sfarsit(lista, 4, 2)
    inlocuire_numar_complex(lista, 4, 5, 2, 7)
    assert lista[1].real == 2,f"test esuat: {lista[1].real}"
    assert lista[1].imaginar == 7,f"test esuat: {lista[1].imaginar}"

def test_afiseaza_partea_imaginara():
    lista = []
    adaugare_numar_complex_la_sfarsit(lista, 9, 8)
    adaugare_numar_complex_la_sfarsit(lista, 4, 5)
    assert afiseaza_partea_imaginara(lista, 0, 1) == [8, 5]

def test_afisare_nr_modul_maimic10():
    lista_test = [
        NrComplex(3, 4),  # Modul = 5
        NrComplex(6, 8),  # Modul = 10
        NrComplex(1, 1),  # Modul ≈ 1.41
        NrComplex(9, 0)  # Modul = 9
    ]
    rezultat = afisare_nr_modul_maimic10(lista_test)
    expected = [NrComplex(3, 4), NrComplex(1, 1), NrComplex(9, 0)]
    assert all(r.real == e.real and r.imaginar == e.imaginar for r, e in zip(rezultat, expected)), \
        f"Test eșuat! Rezultat obținut: {rezultat}, Așteptat: {expected}"

def test_afisare_nr_modul_egal10():
    lista_test = [
        NrComplex(3, 4),  # Modul ≈ 5
        NrComplex(6, 8),  # Modul = 10
        NrComplex(1, 1),  # Modul ≈ 1.41
        NrComplex(9, 0)  # Modul = 9
    ]
    rezultat = afisare_nr_modul_egal10(lista_test)
    expected = [NrComplex(6, 8)]
    assert all(r.real == e.real and r.imaginar == e.imaginar for r, e in zip(rezultat, expected)), \
        f"Test eșuat! Rezultat obținut: {rezultat}, Așteptat: {expected}"

def test_suma_subsecventa():
    lista = [NrComplex(1, 2), NrComplex(3, 4),NrComplex(5, -1),NrComplex(0, 3)]
    suma = suma_subsecventa(lista, 0, 2)
    assert suma.real == 9 and suma.imaginar == 5, f"Test eșuat: {suma}"


def test_produs_subsecventa():
    lista = [NrComplex(1, 2),NrComplex(3, 4),NrComplex(5, -1),NrComplex(0, 3)]
    produs = produs_subsecventa(lista, 0, 1)
    assert produs.real == -5 and produs.imaginar == 10, f"Test eșuat: {produs}"


def test_sortare_descrescator():
    lista = [NrComplex(1, 2),NrComplex(3, 4), NrComplex(5, 3)]
    sortare_descrescator(lista)
    lista_asteptata= [NrComplex(3, 4), NrComplex(5, 3), NrComplex(1, 2)]
    assert lista_asteptata == lista, \
    f"Așteptat: {lista_asteptata}, Obținut: {lista}"


def test_filtrare_parte_reala_prim():
    lista = []
    adaugare_numar_complex_la_sfarsit(lista, 2, 8)
    adaugare_numar_complex_la_sfarsit(lista, 4, 9)
    adaugare_numar_complex_la_sfarsit(lista, 3, 7)
    adaugare_numar_complex_la_sfarsit(lista, 8, 5)
    lista_filtrata = filtrare_parte_reala_prim(lista)
    assert len(lista_filtrata) == 2

def test_filtrare_modul():
    lista_test = [
        NrComplex(3, 4),  # Modul = 5.0
        NrComplex(6, 8),  # Modul = 10.0
        NrComplex(1, 1),  # Modul ≈ 1.41
        NrComplex(5, 12),  # Modul = 13.0
        NrComplex(0, 0),  # Modul = 0.0
    ]

    # Test pentru opțiunea 1: < n
    rezultat = filtrare_modul(lista_test, 1, 10)
    expected = [NrComplex(6, 8), NrComplex(5, 12)]
    assert rezultat == expected,\
        f"Test eșuat pentru opțiunea 1: Rezultat obținut: {rezultat}"

    # Test pentru opțiunea 2: = n
    rezultat = filtrare_modul(lista_test, 2, 10)
    expected = [NrComplex(3, 4),NrComplex(1,1),NrComplex(5,12),NrComplex(0,0)]
    assert rezultat==expected,\
    f"Test eșuat pentru opțiunea 3: Rezultat obținut: {rezultat}"

    # Test pentru opțiunea 3: > n
    rezultat = filtrare_modul(lista_test, 3, 10)
    expected = [NrComplex(3, 4),NrComplex(6,8), NrComplex(1,1),NrComplex(0,0)]
    assert rezultat==expected,\
        f"Test eșuat pentru opțiunea 3: Rezultat obținut: {rezultat}"

def test_undo():
    undo_lista = []  # Resetăm stiva pentru fiecare test

    # Test 1: Nu există stări anterioare
    lista_initiala = [NrComplex(1, 2), NrComplex(3, 4), NrComplex(5, 6)]
    rezultat = undo(lista_initiala, undo_lista)
    assert rezultat == lista_initiala, "Test 1 eșuat: trebuie să returneze lista originală."

    # Test 2: Undo după salvarea unei stări
    istoric([NrComplex(1, 2), NrComplex(3, 4)], undo_lista)  # Salvăm o stare
    lista_modificata = [NrComplex(1, 2), NrComplex(3, 4), NrComplex(5, 6)]
    rezultat = undo(lista_modificata, undo_lista)  # Facem undo pe lista modificată
    assert rezultat == [NrComplex(1, 2), NrComplex(3, 4)], "Test 2 eșuat: trebuie să revină la ultima stare salvată."

    # Test 3: Undo după mai multe stări
    istoric([NrComplex(2, 3), NrComplex(4, 5)], undo_lista)
    istoric([NrComplex(1, 1)], undo_lista)
    lista_modificata = [NrComplex(2, 2)]
    rezultat = undo(lista_modificata, undo_lista)
    assert rezultat == [NrComplex(1, 1)], "Test 3 eșuat: trebuie să revină la ultima stare salvată."

    # Test 4: Undo când stiva este goală
    undo_lista.clear()  # Asigurăm că stiva e goală
    rezultat = undo(lista_initiala, undo_lista)
    assert rezultat == lista_initiala, "Test 4 eșuat: trebuie să returneze lista originală."



