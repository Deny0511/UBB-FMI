

#include <QApplication>
#include "gui.h"
#include "repo.h"
#include "validator.h"
#include "service.h"

int main(int argc, char* argv[]) {
    QApplication a(argc, argv);

    Repo repo;
    Validator val;
    Service srv{ repo, val };

    Gui gui{ srv };
    gui.show();

    return a.exec();
}
