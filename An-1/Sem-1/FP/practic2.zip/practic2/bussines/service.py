from domeniu.examene import Examene


class Service:
    def __init__(self,repo,valid):
        self.__repo = repo
        self.__valid = valid

    def add(self,id,data,ora,materia,sesiunea):
        examen = Examene(id,data,ora,materia,sesiunea)
        self.__valid.valideaza_examen(examen)
        self.__repo.add(examen)

    def get_examen(self):
        return self.__repo.get_examen()

    def get_all(self):
        return self.__repo.get_all()

    def set_data(self,data):
        return self.__repo.set_data(data)

    def export(self,nume_fisier,materie):
        return self.__repo.export(nume_fisier,materie)