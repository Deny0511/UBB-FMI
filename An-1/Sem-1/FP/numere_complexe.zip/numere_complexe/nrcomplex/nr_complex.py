class NrComplex:
    def __init__(self, real, imaginar):
        self.real = real
        self.imaginar = imaginar

    def __repr__(self):
        if self.imaginar >= 0:
            return f"{self.real} + {self.imaginar}i"
        else:
            return f"{self.real} - {abs(self.imaginar)}i"

    def __eq__(self, other):
        if type(other) == NrComplex:
            return (self.real == other.real) and (self.imaginar == other.imaginar)
        return False


    def modul(self):
        return (self.real ** 2 + self.imaginar ** 2) ** 0.5


def get_nr_complex_real(lista):
    return lista[0].real

def get_nr_complex_imaginar(lista):
    return lista[0].imaginar


