// #ifndef GUI_H
// #define GUI_H
//
// #include <QWidget>
// #include <QPushButton>
// #include <QLineEdit>
// #include <QLabel>
// #include <QVBoxLayout>
// #include <QHBoxLayout>
// #include <QListView>
// #include <QMessageBox>
// #include "service.h"  // Include service pentru a apela metodele
//
// class GUI : public QWidget
// {
//     Q_OBJECT
//
// private:
//     Service& service;  // Referință la service pentru a manipula filmele
//     QVBoxLayout* mainLayout;
//
//     QLineEdit* titluEdit;
//     QLineEdit* genEdit;
//     QLineEdit* anEdit;
//     QLineEdit* actorEdit;
//
//     QPushButton* adaugaButton;
//     QPushButton* stergeButton;
//     QPushButton* modificaButton;
//     QPushButton* undoButton;
//
//     QListView* listView;
//
//
//
// public:
//     explicit GUI(Service& srv, QWidget* parent = nullptr);
//     virtual ~GUI();
//
//     private slots:
//         void adaugaFilm();
//     void stergeFilm();
//     void modificaFilm();
//     void undo();
//     void actualizeazaListaFilme();
// };
//
// #endif // GUI_H
