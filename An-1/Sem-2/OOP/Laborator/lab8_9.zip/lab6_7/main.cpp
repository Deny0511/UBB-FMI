#include "teste.h"
#include "ui.h"
#include "validator.h"
#include "CosFilme.h"
#include <fstream>

//#include <QApplication>
//#include <QWidget>


int main() {

    Teste::ruleazaTeste();

  //  QApplication app(argc, argv);

    Repo repo;
    //RepoNou repo_nou{30};
    RepoFile repo_file{"filme1.txt"};
    Validator validator;
    CosFilm cosInchiriei;
    Service service{ repo_file, validator, cosInchiriei };
    UI ui{ service };
    ui.run();
    return 0;

    //return app.exec();
}
