from bussines.service import Service
from repository.repo import Repository
from valid.validator import Validat
from interfata.uii import UI

cale_fisier = "sedinte.txt"
repo = Repository(cale_fisier)
valid = Validat()
service = Service(repo,valid)
ui = UI(service)
ui.run()
