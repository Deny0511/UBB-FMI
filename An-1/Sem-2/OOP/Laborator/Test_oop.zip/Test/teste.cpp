#include "teste.h"
#include <assert.h>
#include "service.h"
#include "domeniu.h"
#include "repo.h"
#include "validator.h"



void Teste::testDomeniu() {
    Jucator j1;
    assert(j1.getNume() == "");
    assert(j1.getTara() == "");
    assert(j1.getMeciuri() == 0);
    assert(j1.getPuncte() == 0);
    assert(j1.getRecuperari() == 0);
    assert(j1.getAssist() == 0);

    Jucator j2("Ion Am", "Romania", 10, 150, 40, 30);
    assert(j2.getNume() == "Ion Am");
    assert(j2.getTara() == "Romania");
    assert(j2.getMeciuri() == 10);
    assert(j2.getPuncte() == 150);
    assert(j2.getRecuperari() == 40);
    assert(j2.getAssist() == 30);

    std::string nouNume = "Ionel Pop";
    std::string nouaTara = "Italia";
    j2.setNume(nouNume);
    j2.setTara(nouaTara);
    j2.setMeciuri(20);
    j2.setPuncte(200);
    j2.setRecuperari(50);
    j2.setAssist(40);

    assert(j2.getNume() == "Ionel Pop");
    assert(j2.getTara() == "Italia");
    assert(j2.getMeciuri() == 20);
    assert(j2.getPuncte() == 200);
    assert(j2.getRecuperari() == 50);
    assert(j2.getAssist() == 40);

    Jucator j3("Ionel Pop", "Italia", 20, 200, 50, 40);
    assert(j2 == j3);
}

void Teste::testRepo() {
        Repo repo;
        Jucator j1("Ana Maria", "Romania", 10, 100, 30, 20);
        Jucator j2("Ion Grad", "Serbia", 12, 180, 45, 35);

        assert(repo.getAll().size() == 0);

        repo.adauga(j1);
        repo.adauga(j2);

        assert(repo.getAll().size() == 2);
        assert(repo.getAll()[0] == j1);
        assert(repo.getAll()[1] == j2);

        try {
            repo.adauga(j1);
            assert(false);
        } catch (std::invalid_argument& e) {
            assert(std::string(e.what()) == "Trafic already exists");
        }

        std::vector<Jucator> listaNoua = {j2};
        repo.setAll(listaNoua);
        assert(repo.getAll().size() == 1);
        assert(repo.getAll()[0] == j2);

}



void Teste::testService() {
    Repo repo;
    Validator val;
    Service service{repo,val};

    assert(service.getAll().size() == 0);

    service.addJucator("Ana Maria", "Romania");
    service.addJucator("Ion Grad", "Serbia");

    assert(repo.getAll().size() == 2);

    try {
        service.addJucator("Ana Maria", "Romania");
        assert(false);
    } catch (std::invalid_argument& e) {
        assert(std::string(e.what()) == "Trafic already exists");
    }

}


void Teste::testValidator() {
    Validator val;
    Repo repo;
    Service service{repo,val};

    try {
        Jucator jucValid;
        service.addJucator("Ion Popescu", "Romania");
        val.valideaza(jucValid);
    } catch (...) {
        assert(false);
    }

    try {
        Jucator juc;
        service.addJucator("Iodd", "Romania");
        val.valideaza(juc);
        assert(false);
    } catch (const std::invalid_argument& ex) {
        assert(std::string(ex.what()).find("Numele trebuie sa aiba cel putin doua cuvinte!") != std::string::npos);
    }

    try {
        Jucator juc;
        service.addJucator("Ion Popescu", "Ro");
        val.valideaza(juc);
        assert(false);
    } catch (const std::invalid_argument& ex) {
        assert(std::string(ex.what()).find("Numele tarii este prea scurta!") != std::string::npos);
    }

    try {
        Jucator juc;
        service.addJucator("Io", "ro");
        val.valideaza(juc);
        assert(false);
    } catch (const std::invalid_argument& ex) {
        std::string msg = ex.what();
        assert(msg.find("Numele este prea scurt!") != std::string::npos);
        assert(msg.find("Numele tarii este prea scurta!") != std::string::npos);
        assert(msg.find("Numele tarii trebuie sa inceapa cu litera mare!") != std::string::npos);
        assert(msg.find("Numele trebuie sa aiba cel putin doua cuvinte!") != std::string::npos);
    }

}



void Teste::ruleazaTeste(){
    testDomeniu();
    testRepo();
    testService();
    testValidator();

}

